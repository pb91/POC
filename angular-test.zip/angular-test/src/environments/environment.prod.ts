export const production = true;
export const environment = {
    production: true,
     api_url: '/' + instance_name + '/admin/index.php/'
   // api_url: server_url + instance_name,
};
