import {
  Component, Input, Output, EventEmitter
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import {BpnCampaignService} from '@bpn/bpn-campaign.service';
import {SharedServiceConstants} from '@shared/shared-service-constants';



@Component({
  selector: 'ngn-conversion-tracking',
  templateUrl: './conversion-tracking.component.html',
  styles: []
})
export class ConversionTrackingComponent {
  @Input() setupForm: FormGroup;
  @Output() operationOnFormArray = new EventEmitter();
  activitiesList : Array<any>
  operatorList : Array<any> =[];

  constructor( private bpnCampaignService : BpnCampaignService ) {

  }

  ngOnInit(){
    this.bpnCampaignService.getActivityList().subscribe((val)=>{
      this.activitiesList = val.data;

    })

    Object.values(SharedServiceConstants.operatorMapping).forEach((obj:Array<any>)=> this.operatorList.push(...obj))
    this.operatorList =  this.operatorList.map(obj=>obj.value).sort().filter((o,p,a)=>{
      return a[p -1] !== o
    })
  }

  onAdd(index, op) {
    this.operationOnFormArray.emit({ op, index });
  }

  onMinus(index, op) {
    this.operationOnFormArray.emit({ op, index })
  }




}
