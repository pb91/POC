import {
  Component, OnInit, Output,
} from '@angular/core';

import { FormGroup, FormControl, FormControlName, Validators, FormArray, FormBuilder } from '@angular/forms'
import { BpnCampaignService } from '@bpn/bpn-campaign.service'
import { SharedService } from '@shared/shared.service.ts';


@Component({
  selector: 'ngn-bpn-setup',
  templateUrl: './bpn-setup.component.html',
  styleUrls: ['./bpn-setup.component.scss']
})
export class BpnSetupComponent implements OnInit {
  setupForm: FormGroup;
  websiteList: Array<any>;
  advanceForm : boolean;

  constructor(private bpnService: BpnCampaignService , private formBuilder : FormBuilder , private sharedService : SharedService) {

  }

  ngOnInit() {
  
    this.bpnService.getWebsiteList().subscribe((data) => {
      this.websiteList = [...data.data];
    })
    this.setupForm = new FormGroup({
      'name': new FormControl(null, [Validators.required, Validators.maxLength(100), Validators.pattern('[a-zA-Z0-9-_&@:?]*')]),
      'website': new FormControl(null),
      'advance': new FormControl(null),
      'conversion': this.formBuilder.array([
        ]) 
    })

    this.setupForm.get('advance').valueChanges.subscribe((val)=>{
      if(val){
        this.advanceForm = val;
        (<FormArray>this.setupForm.get('conversion')).push(this.createItem());
      }else{
        this.advanceForm = val;
        (<FormArray>this.setupForm.get('conversion')).controls.length = 0;
      }
    })
    
  }

  onSubmit() {
    console.log(this.setupForm)
    //this.submit.emit(this.setupForm.value)
    this.sharedService.pushNotify(this.setupForm.value)
  }

  createItem(): FormGroup {
    return this.formBuilder.group({
      payload: new FormControl(null , Validators.required),
      operator: new FormControl(null , Validators.required),
      val: new FormControl(null , Validators.required)
    });
  }



  operationOnFormArray({op , index}) {

    switch (op) {
      case 'ADD':
        (<FormArray>this.setupForm.get('conversion')).push(this.createItem());
        break;
      case 'REMOVE':
        if(event){
         (<FormArray>this.setupForm.get('conversion')).removeAt(index)
        }
        
      default:
    }

  }

}
