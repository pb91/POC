import { Component } from '@angular/core';
import { SharedService } from '@shared/shared.service.ts';
import { Subscription } from 'rxjs';

@Component({
  selector: 'ngn-bpn-create',
  templateUrl: './bpn-create.component.html',
  styleUrls: ['./bpn-create.component.scss'],
})
export class BpnCreateComponent {
  setupForm : any;
  subscription: Subscription;
  constructor( private sharedService : SharedService){

   this.subscription = this.sharedService.pullNotify().subscribe(form => {
    if (form) {
      this.setupForm = form;
      console.log(this.setupForm)
    } else {
   
     
    }
  });
  }


}
