export class BlockUIActions {
    static START = 'start';
    static STOP = 'stop';
    static UPDATE = 'update';
    static RESET = 'reset';
    static UNSUBSCRIBE = 'unsubscribe';
}