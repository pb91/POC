export const BlockUIDefaultName: string = `block-ui-main`;
