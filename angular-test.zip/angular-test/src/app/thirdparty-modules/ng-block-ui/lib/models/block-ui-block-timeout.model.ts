export interface BlockTimeout {
  delayStart: any;
  delayStop: any;
}
